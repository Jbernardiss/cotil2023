public class Main {
    public static void main(String[] args) {

        CalculoMatematico mat = new CalculoMatematico();

        mat.divisao(4, 0);
    }
}