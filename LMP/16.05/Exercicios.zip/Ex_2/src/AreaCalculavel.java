public interface AreaCalculavel {
    public double calcularArea();
}
