/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author taniabasso
 */
public class Conexao {
    public Connection getConnection() throws SQLException, ClassNotFoundException {    
       
       String driver = "com.mysql.cj.jdbc.Driver"; 
       String url = "jdbc:mysql://localhost:3306/aulaBD1";
       String usuario = "root";
       String senha = "root1234";
       Class.forName(driver);
       return DriverManager.getConnection(url, usuario, senha); 
    }
}
