public class Main {
    public static void main(String[] args) {
        Ponto2D ponto1 = new Ponto2D(1, 2);
        Ponto3D ponto2 = new Ponto3D(1, 2, 4);

        System.out.println(ponto1.toString());
        System.out.println(ponto2.toString());


    }
}