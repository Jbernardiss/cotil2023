public class SaldoInsuficienteException extends RuntimeException{

    double saldo;

    public SaldoInsuficienteException(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String getMessage(){
        return "Saldo insuficiente, não foi possível realizar transações! Saldo Atual: " + saldo;
    }
}
