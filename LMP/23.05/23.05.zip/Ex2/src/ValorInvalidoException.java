public class ValorInvalidoException extends RuntimeException{
    double valor;

    public ValorInvalidoException(double valor) {
        this.valor = valor;
    }

    @Override
    public String getMessage(){
        return "Valor igual ou inferior a zero, não foi possível realizar as transações! Valor utilizado: " + valor;
    }
}
