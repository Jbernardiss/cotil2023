public class Main {
    public static void main(String[] args) {
        Medico medico = new Medico(true);
        Cirurgiao cirurgiao = new Cirurgiao(true);
        ClinicoGeral clinicoGeral = new ClinicoGeral(true, false);

    }
}