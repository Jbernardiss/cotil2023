public class Cirurgiao extends Medico{
    public Cirurgiao(boolean trabalhaNoHospital){
        super(trabalhaNoHospital);
    }

    @Override
    public void tratarPaciente(){

    }

    public void fazerIncisao(){

    }

}
