public class Medico {
    private boolean trabalhaNoHospital;

    public Medico(boolean trabalhaNoHospital){
        this.trabalhaNoHospital = trabalhaNoHospital;
    }
    public void tratarPaciente(){

    }
}
