public interface IPessoa {

    public void exibir();
}
