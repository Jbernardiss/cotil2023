public interface TipoPagamento {

    public int getDiasFaturamento();
    public double getPorcentagemFinanceira();
}
