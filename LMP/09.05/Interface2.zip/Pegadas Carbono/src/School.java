public class School extends Building{
    public School(int numeroPessoas, boolean usoEnergiaRenovavel, int numeroDeLampadas, boolean usaArCondicionado) {
        super(numeroPessoas, usoEnergiaRenovavel, numeroDeLampadas, usaArCondicionado);
    }
}
