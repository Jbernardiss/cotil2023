public class House extends Building{
    public House(int numeroPessoas, boolean usoEnergiaRenovavel, int numeroDeLampadas, boolean usaArCondicionado) {
        super(numeroPessoas, usoEnergiaRenovavel, numeroDeLampadas, usaArCondicionado);
    }
}
