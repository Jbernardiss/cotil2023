public interface CarbonFootprint {
    public int getCarbonFootprint();
}
