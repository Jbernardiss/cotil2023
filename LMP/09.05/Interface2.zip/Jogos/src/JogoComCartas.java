public abstract class JogoComCartas implements Jogo{

    public abstract int qtdCartasDistribuidas();
    public abstract int numeroParticipantes();
}
