public abstract class JogoComBola implements Jogo {

    public abstract void setNomesEquipes(String equipe1, String equipe2);
}
