public interface Jogo {

    public void iniciar();
    public void jogar();
    public void finalizar();
}
