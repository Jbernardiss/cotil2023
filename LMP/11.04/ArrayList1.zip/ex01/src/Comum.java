public class Comum extends Ingresso{
    public Comum(double reais) {
        super(reais);
    }
}
