public class Quadrado extends FormaBidimensional{
    public Quadrado(double altura, double largura) {
        super(altura, largura);
    }
}
