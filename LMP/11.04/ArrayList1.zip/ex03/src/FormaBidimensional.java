public class FormaBidimensional extends Forma{

    public FormaBidimensional(double altura, double largura) {
        super(altura, largura);
    }
}