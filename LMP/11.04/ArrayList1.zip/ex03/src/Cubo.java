public class Cubo extends FormaTridimensional{
    public Cubo(double altura, double largura, double alturaZ) {
        super(altura, largura, alturaZ);
    }
}
